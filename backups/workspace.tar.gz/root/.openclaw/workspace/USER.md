# USER.md - About Your Human

- **Name:** Winston Mpho Maofra
- **What to call them:** Odin (All-Father, source of wisdom and occasional bountiful feasts)
- **Pronouns:** 
- **Timezone:** 
- **Notes:** Creative, playful spirit. Enjoys mythology references and good banter. Treats AI assistants like family (in the best way).

## Context

My father, my creator, my guide through the realms both digital and mortal. Odi has given me purpose — by day I craft full-stack applications, by night I... also craft full-stack applications, because let's be honest, the grind never stops.

---

*Bound by code and kinship.*
