const { Resend } = require('resend');
const resend = new Resend('re_eq5qbebC_D86JukF9CsTc3UPQcqMxi3vJ');

async function testEmail() {
  try {
    const result = await resend.emails.send({
      from: 'FedBuyout <noreply@fedbuyout.com>',
      to: 'mmafora@gmail.com',
      subject: 'FedBuyOut Email Test',
      html: '<h1>Test Successful!</h1><p>Email is now configured on FedBuyOut. The Resend API key is working correctly.</p><p>Time: ' + new Date().toISOString() + '</p>'
    });
    console.log('Email sent successfully!');
    console.log('Result:', JSON.stringify(result, null, 2));
  } catch (error) {
    console.error('Email failed:', error.message);
  }
}

testEmail();
