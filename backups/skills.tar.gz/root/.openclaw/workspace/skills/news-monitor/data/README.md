# News Monitor Data Directory

This directory stores:
- `articles.json` - Tracked articles database
- `alerts.json` - Alert history
- `digests/` - Generated weekly digests

Data is stored in JSON format for easy querying and backup.
