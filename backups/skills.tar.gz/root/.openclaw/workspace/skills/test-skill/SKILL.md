---
name: test-skill
description: A test skill
version: 1.0.0
author: Your Name
tags: []
dependencies: []
---

# Test Skill

A test skill

## Quick Start

Describe how to use this skill quickly.

## Features

- Feature 1
- Feature 2
- Feature 3

## Usage

### Example Command

```bash
# Add example usage here
```

## Configuration

Describe any configuration options.

## Resources

List any resources or references.

## Changelog

### v1.0.0 (2026-02-03)
- Initial release
